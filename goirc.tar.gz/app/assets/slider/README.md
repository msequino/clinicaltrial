# ui-slider directive

Due to popular demand. This is WIP so expect breaking changes!

## Requirements

- JQuery
- JQueryUI
- AngularJS

## Usage

Check the [demo](http://angular-ui.github.io/ui-slider/demo/demo.html) for an example on how it works.

